﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ControlPanel.Services
{
    public static class Paths
    {
        public static string ExamDetailPath { get; set; } = "http://localhost:50035/images/";

        //public static string ExamDetailPath { get; set; } = "http://adlink2019-001-site16.etempurl.com/images/";
        public static string HomeworkPath { get; set; } = "http://adlink2019-001-site16.etempurl.com/homeworks/";
    }
}